import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Event;

import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class GUI extends JFrame implements KeyListener {
	
	JTextField polje;
	JButton confirm, clear;
	JTextArea area_result, area_latex;
	JRadioButtonMenuItem Solve, Factor, Plot, Taylor, Integrate, Differentiate, Latex, LatexAll;
	ButtonGroup group=new ButtonGroup();
	JLabel label1, label2, label3;
	JScrollPane jp1, jp2;

	public GUI(){
		super("Maple");
		this.setSize(700, 600);
		this.popuniProzor();
		
		this.setVisible(true);
		
	}
	
	

	private void popuniProzor() {
				
		JPanel left , right, dugmici, rightsouth, rightnorth, poljetekst, pomocno;
		
		this.setLayout(new GridLayout(1,2));
		
		left = new JPanel();
		left.setLayout(new BorderLayout());
		left.setBackground(Color.BLACK);
		
		right = new JPanel();
		right.setLayout(new GridLayout(2,1));
		
		rightsouth = new JPanel();
		rightsouth.setLayout(new BorderLayout());
		rightsouth.setBackground(Color.BLACK);
		
		rightnorth = new JPanel();
		rightnorth.setLayout(new BorderLayout());
		rightnorth.setBackground(Color.BLACK);
		
		poljetekst = new JPanel();
		poljetekst.setLayout(new GridLayout(2,1));
		
		pomocno = new JPanel();
		pomocno.setLayout(new GridLayout(1,2));
		
		dugmici = new JPanel();
		dugmici.setBackground(Color.WHITE);
		dugmici.setLayout( new GridLayout(4,2));
		
		area_result = new JTextArea(390,300);
		area_result.setBounds(50, 100, 380, 240);
		area_latex = new JTextArea();		
		area_result.setLineWrap(true);

		left.setBounds(10, 10, 330, 580);
		
		this.polje = new JTextField();
		polje.setFont(new Font("Luka", 0 , 20));
		polje.setBounds(0, 0, 20, 20);
		
		
		
		
		pomocno.add(this.clear = new JButton("Clear"));
		pomocno.add(this.confirm = new JButton("Confirm"));
		poljetekst.add(polje);
		poljetekst.add(pomocno);



		
		group.add(Solve=new JRadioButtonMenuItem("Solve", false));
		dugmici.add(Solve, BorderLayout.CENTER);
		group.add(Factor=new JRadioButtonMenuItem("Factor", false));
		dugmici.add(Factor);
		group.add(Plot=new JRadioButtonMenuItem("Plot", false));
		dugmici.add(Plot);
		group.add(Taylor=new JRadioButtonMenuItem("Taylor", false));
		dugmici.add(Taylor);
		group.add(Integrate=new JRadioButtonMenuItem("Integrate", false));
		dugmici.add(Integrate);
		group.add(Differentiate=new JRadioButtonMenuItem("Differentiate", false));
		dugmici.add(Differentiate);
		group.add(Latex=new JRadioButtonMenuItem("Latex", false));
		dugmici.add(Latex);
		group.add(LatexAll=new JRadioButtonMenuItem("LatexAll", false));
		dugmici.add(LatexAll);
	
		Solve.setBackground(Color.BLACK);
		Solve.setForeground(Color.WHITE);
		Factor.setBackground(Color.BLACK);
		Factor.setForeground(Color.WHITE);
		Plot.setBackground(Color.BLACK);
		Plot.setForeground(Color.WHITE);
		Taylor.setBackground(Color.BLACK);
		Taylor.setForeground(Color.WHITE);
		Integrate.setBackground(Color.BLACK);
		Integrate.setForeground(Color.WHITE);
		Differentiate.setBackground(Color.BLACK);
		Differentiate.setForeground(Color.WHITE);
		Latex.setBackground(Color.BLACK);
		Latex.setForeground(Color.WHITE);
		LatexAll.setBackground(Color.BLACK);
		LatexAll.setForeground(Color.WHITE);
		
		
		left.setBorder(new EmptyBorder(10,10,10,5));
		rightnorth.setBorder(new EmptyBorder(10,5,10,10));
		rightsouth.setBorder(new EmptyBorder(10,5,10,10));

		
		rightnorth.add(label2=new JLabel ("Most common functions in Maple", JLabel.CENTER), BorderLayout.NORTH);
		rightnorth.add(dugmici, BorderLayout.CENTER);
		rightnorth.add(poljetekst, BorderLayout.SOUTH);
		
		rightsouth.add(label3 = new JLabel("Latex area", JLabel.CENTER), BorderLayout.NORTH);
		rightsouth.add(area_latex, BorderLayout.CENTER);
		
		right.add(rightnorth, BorderLayout.NORTH);
		right.add(rightsouth, BorderLayout.SOUTH);
		
		left.add(label1 =new JLabel("Maple result", JLabel.CENTER), BorderLayout.NORTH);
		
		left.add(area_result);		
		
		label1.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label3.setForeground(Color.WHITE);
		
		jp1=new JScrollPane(area_result, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp2=new JScrollPane(area_latex, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		left.add(jp1);
		rightsouth.add(jp2);
		
		
		this.add(left, BorderLayout.WEST);
		this.add(right, BorderLayout.EAST);
		
		
		this.polje.addKeyListener(this);
		
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				polje.setText("");
				group.clearSelection();
				
				
			}
		});
		
			
		
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Maple.procitano = true;
				Maple.done = true;
				dispose();
			}
		});
		
		
		confirm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {				
				String fja=polje.getText();
				polje.setText("");
				String txt;
				
				if(Solve.isSelected()) {
					txt="solve("+fja+");";
					polje.setText(txt);
					
				}
				else if(Factor.isSelected()) {
					txt="factor("+fja+");";
					polje.setText(txt);
				}
				else if(Plot.isSelected()) {
					txt="plot("+fja+");";
					polje.setText(txt);
				}
				else if(Taylor.isSelected()) {
					txt="taylor("+fja+");";
					polje.setText(txt);
				}
				else if(Integrate.isSelected()) {
					txt="integrate("+fja+");";
					polje.setText(txt);
				}
				else if(Differentiate.isSelected()) {
					txt="diff("+fja+");";
					polje.setText(txt);
				}
				else if(Latex.isSelected()) {
					txt="latex("+fja+");";
					polje.setText(txt);
				}
				else if(LatexAll.isSelected()) {
					txt="";
					polje.setText(txt);
				}
				else {
					if (fja == "") { 
					txt="";
					polje.setText(txt);
					}
					else {
						txt=fja;
						polje.setText(fja);
					}
				}
								
				group.clearSelection();
				Maple.procitano = true;

			}
		});
		
		
		
	}



	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			
			confirm.doClick();			
			
		}
		
	}



	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
		
}
	
	


