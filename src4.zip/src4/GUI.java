import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class GUI extends JFrame implements KeyListener {
	
	JTextField polje;
	JButton confirm, clear, clearR, clearL;
	JTextArea area_result, area_latex;
	JRadioButtonMenuItem Solve, Factor, Plot, Taylor, Integrate, Differentiate, Latex, LatexAll;
	ButtonGroup group=new ButtonGroup();
	JLabel label1, label2, label3;
	JScrollPane jp1, jp2;
	

	public GUI(){
		super("Maple");
		this.setBounds(160,40, 1050,700);
		this.popuniProzor();
		
		this.setVisible(true);
		
	}

	private void popuniProzor() {
		
				
		JPanel left ,leftsouth, right, dugmici, rightsouth, rightnorth, poljetekst, pomocno;
		
		
		this.setLayout(new GridLayout(1,2));	
		
		
		left = new JPanel();
		left.setLayout(new BorderLayout());
		left.setBackground(Color.BLACK);
		
		
		leftsouth = new JPanel();
		leftsouth.setLayout(new GridLayout(1,2));
		
		clearR = new JButton("Clear results");
		clearL = new JButton("Clear latex");
		
		leftsouth.add(clearR);
		leftsouth.add(clearL);
		
		
		right = new JPanel();
		right.setLayout(new GridLayout(2,1));
		
		rightsouth = new JPanel();
		rightsouth.setLayout(new BorderLayout());
		rightsouth.setBackground(Color.BLACK);
		
		rightnorth = new JPanel();
		rightnorth.setLayout(new BorderLayout());
		rightnorth.setBackground(Color.BLACK);
		
		poljetekst = new JPanel();
		poljetekst.setLayout(new GridLayout(2,1));
		
		pomocno = new JPanel();
		pomocno.setLayout(new GridLayout(1,2));
		
		dugmici = new JPanel();
		dugmici.setBackground(Color.WHITE);
		dugmici.setLayout( new GridLayout(4,2));
		
		area_result = new JTextArea(390,300);
		area_result.setBounds(50, 100, 380, 240);
		area_result.setEditable(false);
		area_latex = new JTextArea();		
		area_result.setLineWrap(true);
	//	area_result.setFont(new Font("Marija", 0, 20));
		area_latex.setFont(new Font("Nikola", 0, 18));
		
		

		left.setBounds(10, 10, 330, 580);
		
		this.polje = new JTextField();
		polje.setFont(new Font("Luka", 0 , 20));
		polje.setBounds(0, 0, 20, 20);
		
		
		
		
		pomocno.add(this.clear = new JButton("Clear"));
		pomocno.add(this.confirm = new JButton("Confirm"));
		poljetekst.add(polje);
		
		polje.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				polje.setForeground(Color.BLACK);
				polje.setText("");
			}
			
		});
		
		
		poljetekst.add(pomocno);

		
		group.add(Solve=new JRadioButtonMenuItem("Solve", false));
		Solve.setFont(new Font("Jokic", 0,25));
		Solve.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x)");
				
				
			}
			
		});
		dugmici.add(Solve, BorderLayout.CENTER);
		group.add(Factor=new JRadioButtonMenuItem("Factor", false));
		Factor.setFont(new Font("NazivFonta", 0,25));
		Factor.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x)");
				
				
			}
			
		});
		dugmici.add(Factor);
		group.add(Plot=new JRadioButtonMenuItem("Plot", false));
		Plot.setFont(new Font("PrazanString", 0,25));
		Plot.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x=a..b");
				
				
			}
			
		});
		dugmici.add(Plot);
		group.add(Taylor=new JRadioButtonMenuItem("Taylor", false));
		Taylor.setFont(new Font("prazan", 0, 25));
		Taylor.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x, num");
				
				
			}
			
		});
		dugmici.add(Taylor);
		group.add(Integrate=new JRadioButtonMenuItem("Integrate", false));
		Integrate.setFont(new Font("",0,25));
		Integrate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x=a..b");
				
				
			}
			
		});
		dugmici.add(Integrate);
		group.add(Differentiate=new JRadioButtonMenuItem("Differentiate", false));
		Differentiate.setFont(new Font("", 0, 25));
		Differentiate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x");
				
				
			}
			
		});
		dugmici.add(Differentiate);
		group.add(Latex=new JRadioButtonMenuItem("Latex", false));
		Latex.setFont(new Font("",0,25));
		Latex.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x)");
				
				
			}
			
		});
		dugmici.add(Latex);
		group.add(LatexAll=new JRadioButtonMenuItem("LatexAll", false));
		LatexAll.setFont(new Font("",0,25));
		dugmici.add(LatexAll);
	
		Solve.setBackground(Color.BLACK);
		Solve.setForeground(Color.WHITE);
		Factor.setBackground(Color.BLACK);
		Factor.setForeground(Color.WHITE);
		Plot.setBackground(Color.BLACK);
		Plot.setForeground(Color.WHITE);
		Taylor.setBackground(Color.BLACK);
		Taylor.setForeground(Color.WHITE);
		Integrate.setBackground(Color.BLACK);
		Integrate.setForeground(Color.WHITE);
		Differentiate.setBackground(Color.BLACK);
		Differentiate.setForeground(Color.WHITE);
		Latex.setBackground(Color.BLACK);
		Latex.setForeground(Color.WHITE);
		LatexAll.setBackground(Color.BLACK);
		LatexAll.setForeground(Color.WHITE);
		
		
		left.setBorder(new EmptyBorder(10,10,10,5));
		rightnorth.setBorder(new EmptyBorder(10,5,10,10));
		rightsouth.setBorder(new EmptyBorder(10,5,10,10));

		
		rightnorth.add(label2=new JLabel ("Most common functions in Maple", JLabel.CENTER), BorderLayout.NORTH);
		rightnorth.add(dugmici, BorderLayout.CENTER);
		rightnorth.add(poljetekst, BorderLayout.SOUTH);
		
		rightsouth.add(label3 = new JLabel("Latex area", JLabel.CENTER), BorderLayout.NORTH);
		rightsouth.add(area_latex, BorderLayout.CENTER);
		
		right.add(rightnorth, BorderLayout.NORTH);
		right.add(rightsouth, BorderLayout.SOUTH);
		
		left.add(label1 =new JLabel("Maple result", JLabel.CENTER), BorderLayout.NORTH);
		
		left.add(area_result);		
		
		left.add(leftsouth, BorderLayout.SOUTH);
		
		label1.setForeground(Color.WHITE);
		label1.setFont(new Font("",0,25));
		label2.setForeground(Color.WHITE);
		label2.setFont(new Font("",0,25));
		label3.setForeground(Color.WHITE);
		label3.setFont(new Font("",0,25));
		
		jp1=new JScrollPane(area_result, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp2=new JScrollPane(area_latex, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		left.add(jp1);
		rightsouth.add(jp2);
		
		
		this.add(left, BorderLayout.WEST);
		this.add(right, BorderLayout.EAST);
		
		
		this.polje.addKeyListener(this);
		
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				polje.setText("");
				group.clearSelection();
				
				
			}
		});
		
			
		
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Maple.procitano = true;
				Maple.done = true;
				dispose();
			}
		});
		
		
		confirm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String fja=polje.getText();
				Maple.fun = fja;
				
				polje.setText("");
				String txt;
				
				if(Solve.isSelected()) {
					txt="solve("+fja+");";
					Maple.dodatak = "solve(";
					polje.setText(txt);
					
				}
				else if(Factor.isSelected()) {
					txt="factor("+fja+");";
					Maple.dodatak = "factor(";
					polje.setText(txt);
				}
				else if(Plot.isSelected()) {
					txt="plot("+fja+");";
					Maple.dodatak = "plot(";
					polje.setText(txt);
				}
				else if(Taylor.isSelected()) {
					txt="taylor("+fja+");";
					Maple.dodatak = "taylor(";
					polje.setText(txt);
				}
				else if(Integrate.isSelected()) {
					txt="integrate("+fja+");";
					Maple.dodatak = "integrate(";
					polje.setText(txt);
				}
				else if(Differentiate.isSelected()) {
					txt="diff("+fja+");";
					Maple.dodatak = "diff(";
					polje.setText(txt);
				}
				else if(Latex.isSelected()) {
					txt="latex("+fja+");";
					Maple.dodatak = "latex(";
					polje.setText(txt);
				}
				else if(LatexAll.isSelected()) {					
					Maple.latexAll = true;
					txt="";
					polje.setText(txt);
				}
	
				else {
					if (fja == "") { 
					txt="";
					polje.setText(txt);
					}
					else {
						txt=fja;
						polje.setText(fja);
					}
				}
								
				area_result.setText(area_result.getText() + " " + txt + "\n");
				
				
				group.clearSelection();			
				
				
				
				Maple.procitano = true;

			}
		});
		
		
		clearR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				area_result.setText("");
			}
		});
		
		clearL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				area_latex.setText("");
			
			}
		});
		
		
	}



	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			
			confirm.doClick();	
			
			group.clearSelection();			
			
		}
		
	}



	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
		
}
	
	
