
import com.maplesoft.externalcall.MapleException;
import com.maplesoft.openmaple.EngineCallBacksDefault;

import java.io.*;
import java.util.LinkedList;

public class JCEngineCallBacks extends EngineCallBacksDefault {
	/* instead of printing the messages to the screen, store them in this list */
	LinkedList queue;
	LinkedList LatexAll;
	GUI myGui;

	public JCEngineCallBacks() {

		queue = new LinkedList<String>();
		LatexAll = new LinkedList<String>();
	}

	/* allow public access for removing lines from the queue */
	public int numOfLines() {

		return queue.size();

	}

	public String getLine() {
		return (String) queue.removeFirst();
	}

	/* only JCEngineCallBacks can add lines into the queue */
	private void addLine(String line) {
		queue.addLast(line);
		
	}

	private void addLineWithOffset(String line, int offset) {
		int i;
		StringBuffer buf = new StringBuffer();

		for (i = 0; i < offset; i++) {
			buf.append(' ');
		}

		buf.append(line);

		queue.addLast(buf.toString());
	
	}

	public void textCallBack(Object data, int tag, String output) throws MapleException {
		int len;

		/* used variables */
		data = null;


		/* different options for different tags */
		switch (tag) {

		/* append "Warning" to the message */
		case MAPLE_TEXT_WARNING:
			break;

		case MAPLE_TEXT_OUTPUT:
			
			if(Maple.converting == true) {
				break;
			}
			
			len = output.length();

			if (len > Maple.myGui.area_result.getWidth()) {				
				addLine(output);
			} else {
				len = (Maple.myGui.area_result.getWidth() - len) / 2;
				addLineWithOffset(output, len);
			}
			break;

		default:
			if(output.contains("bytes")) {
				break;
			}
			if(Maple.expr.contains("latex")) {
				addLine(output);
			}
			if(Maple.converting == true ) {			
				if(Maple.staviDodatak == true) {
					this.LatexAll.addLast(Maple.dodatak + output + ")" + "\n" + "\\newline");
				}else {
					this.LatexAll.addLast(output+ "\n" + "\\newline");
				}
				break;
			}
			
			break;
		}

		
	}

	/*public void errorCallBack(Object data, int offset, String output) throws MapleException {
		if (offset >= 0) {
			
			addLineWithOffset("^", offset);
		} else {
			
			addLine("");
		}

		
		addLine("Error, " + output);
		addLine("");
	}*/
	

	public String readLineCallBack(Object data, boolean debug) throws MapleException {
		
		return Maple.input.getText();
		
	}

}
