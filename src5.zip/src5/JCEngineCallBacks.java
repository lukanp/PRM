
import com.maplesoft.externalcall.MapleException;
import com.maplesoft.openmaple.EngineCallBacksDefault;

import java.io.*;
import java.util.LinkedList;

public class JCEngineCallBacks extends EngineCallBacksDefault {
	/* instead of printing the messages to the screen, store them in this list */
	LinkedList queue;
	LinkedList LatexAll;
	GUI myGui;

	public JCEngineCallBacks() {

		queue = new LinkedList<String>();
		LatexAll = new LinkedList<String>();
	}

	/* allow public access for removing lines from the queue */
	public int numOfLines() {

		return queue.size();

	}

	public String getLine() {
		return (String) queue.removeFirst();
	}

	/* only JCEngineCallBacks can add lines into the queue */
	private void addLine(String line) {
		queue.addLast(line);
		
	}

	private void addLineWithOffset(String line, int offset) {
		int i;
		StringBuffer buf = new StringBuffer();

		for (i = 0; i < offset; i++) {
			buf.append(' ');
		}

		buf.append(line);

		queue.addLast(buf.toString());
	
	}

	public void textCallBack(Object data, int tag, String output) throws MapleException {
		int len;

		
		data = null;
		
		if(Maple.flag == true) return;
		

		/* different options for different tags */
		switch (tag) {
        
		/* append "Warning" to the message */
		case MAPLE_TEXT_WARNING:
			break;

		case MAPLE_TEXT_OUTPUT:
			
			if(Maple.converting == true) {
				break;
			}
			
			len = output.length();

			if (len > Maple.myGui.area_result.getWidth()) {				
				addLine(output);
			} else {
				len = (Maple.myGui.area_result.getWidth() - len) / 2;
				addLineWithOffset(output, len);
			}
			break;

		default:
			
			if(output.contains("bytes")) {
				break;
			}
			if(Maple.expr.contains("latex")) {
				addLine(output);
			}
			if(Maple.converting == true ) {	
				
					if(Maple.staviDodatak == true) {
						String temp = "";
						temp += Maple.dodatak + output;
						
						if(Maple.expr.contains("integrate")) {
							
							temp+= "d" + Maple.promenjiva +"\n" + "\\newline";
							
							
						}else if(Maple.expr.contains("diff")) {
							
							temp+=")}{"+"d" + Maple.promenjiva+"}$$ \n" + "\\newline";
						}else if(Maple.expr.contains("taylor")) {
							
							temp+= ","+Maple.promenjiva+ ","+ Maple.stepen+")$$ \n" + "\\newline";
						}
						else if(Maple.expr.contains("factor"))
							temp +=")$$\n" + "\\newline";
						else if(Maple.expr.contains("solve"))
							temp +=" = 0$$\n" + "\\newline";
						
						
						this.LatexAll.addLast(temp);
						
					}else {
						this.LatexAll.addLast("$$"+ output + "$$\n" + "\\newline");
				
			}
			
			break;
			}
		}
		
	}

	/*public void errorCallBack(Object data, int offset, String output) throws MapleException {
		if (offset >= 0) {
			
			addLineWithOffset("^", offset);
		} else {
			
			addLine("");
		}

		
		addLine("Error, " + output);
		addLine("");
	}*/
	

	public String readLineCallBack(Object data, boolean debug) throws MapleException {
		
		return Maple.input.getText();
		
	}

}
