import com.maplesoft.openmaple.*;
import com.maplesoft.externalcall.MapleException;


import javax.swing.JTextArea;
import javax.swing.JTextField;

class Maple extends Thread{
    /* the Maple session object */
    static private Engine kernel;
    /* the EngineCallBacks object*/
    static private JCEngineCallBacks callbacks;
    
    /* where to read input from */
    static JTextField input;
    /* where to write output to */
    static JTextArea output;
    
    static boolean done=false , procitano = false;
    static GUI myGui = null;
	
    
    public Maple(GUI g) {
    	Maple.myGui = g;    
    }

    /* initialize input, the input source */
    private static void initInputOutput() {
    		Maple.output = Maple.myGui.area;
    		Maple.input = Maple.myGui.polje;
    	
    }

    /* initialize the kernel and callback objects */
    private static void initKernel() {
    	String args[];

    	args = new String[1];
    	args[0] = "java";

    	/* create the callback objects */
    	callbacks = new JCEngineCallBacks();

    	try{
    		/* start the kernel */
    		kernel = new Engine( args, callbacks, null, null );
    		//	kernel = new Engine( args, new EngineCallBacksDefault(), null, null );
    	}
    	catch ( MapleException e ){
    		System.err.println( e.getMessage()+"\n" );
    		System.err.println( "Error starting OpenMaple session\n" );
    		System.exit(1);
    	}
    }

    public static void main( String args[] ){
    	
    	new Maple(new GUI());  
    	
    	initInputOutput();

    	initKernel();      	
    	
    	Maple.myRun();
    	
    }
    	
    	
    public static void myRun() {    	

    	Algebraic ret;
    	
    	String expr;
    	

    	expr = null;
    	ret = null;


    	done = false;
    	while ( !done ){    

    		/* get the input */
    		while ( !procitano ) { 
    			try {
    				Thread.sleep(50);
    			} catch (InterruptedException e) {} 
    		}
    		
    		expr = input.getText();
    	//	expr = Maple.getCommand();
    		
    		
    		if ( done == true){    			
    			break;
    		}
    		
    		/* empty expression */
    		if ( expr.equals( "" ) ) {
    				continue;
    		}
    		   		
    		
    		/* evaluate the expr */
    		try{
    			
    			ret = kernel.evaluate( expr );
  

    			if ( ret != null ){    				
    				done = ret.isStop();
    				ret.dispose();
    			}
    		}catch ( MapleException e ){
    			output.setText(output.getText() + "Error evaluating Maple expression\n" + "\n" );
    			System.exit(1);
	    }
    		/* print out any generated input */
    		while ( callbacks.numOfLines() > 0 ){
    			output.setText(output.getText() + callbacks.getLine() + "\n" );
    		}
    		
    		procitano = false;
    	}

    	try{
    		kernel.stop();
    	}catch ( MapleException me ){}
    }

	private static String getCommand() {
		String command = null;
		/*
		na osnovu gui odrediti sta treba da se prosledi maple-u
		*/
		return command;
	}

}
    
    
    
    



