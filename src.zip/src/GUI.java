import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;


public class GUI extends JFrame {
	
	JTextField polje;
	JButton dugme;
	JTextArea area;


	public GUI(){
		super("Maple");
		this.setBounds(100, 100,900,600);
		
		this.popuniProzor();
		
		this.setVisible(true);
		
	}

	private void popuniProzor() {
		
		this.setLayout( new GridLayout(1,2));
		JPanel left , right;
		left = new JPanel();
		
		right = new JPanel();
		right.setLayout( new GridLayout(2,1));
		
		area = new JTextArea(30,30);
		
		this.polje = new JTextField("factor(s^6+26*s^3-21*s^2-5*s-1);",20);
		polje.setFont(new Font("Luka", 0 , 20));
		polje.setBounds(0, 0, 200, 200);
		
		left.add(area , BorderLayout.CENTER);
		left.add(polje , BorderLayout.SOUTH);
		left.add(this.dugme = new JButton("Evalute"), BorderLayout.NORTH);
		
		this.add(left);
		this.add(right);
		
		dugme.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Maple.procitano = true;
			}
			
		});
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Maple.procitano = true;
				Maple.done = true;
				dispose();
			}
		});
	}

}
