
import com.maplesoft.openmaple.*;
import com.maplesoft.externalcall.MapleException;

import java.io.ByteArrayOutputStream;
import java.io.Console;
import java.io.PrintStream;

import javax.swing.JTextArea;
import javax.swing.JTextField;

class Maple extends Thread{
	static String stepen;
	static String promenjiva;	
	static String dodatak;
	static String fun;
	static boolean notSelected;
	static boolean flag = false;
	static boolean staviDodatak;
	static boolean latexAll = false;
	static boolean converting = false;
	static String expr = "";
    /* the Maple session object */
    static Engine kernel;
    /* the EngineCallBacks object*/
    static JCEngineCallBacks callbacks;
    
    /* where to read input from */
    static JTextField input;
    /* where to write output to */
    static JTextArea output;
    
    static JTextArea output2;
    
    static boolean done=false , procitano = false;
    static GUI myGui = null;	
    
    public Maple(GUI g) {
    	Maple.myGui = g;    
    }

    /* initialize input, the input source */
    private static void initInputOutput() {
    		Maple.output = Maple.myGui.area_result;
    		Maple.output2 = Maple.myGui.area_latex;
    		Maple.input = Maple.myGui.polje;
    	
    }

    /* initialize the kernel and callback objects */
    private static void initKernel() {
    	String args[];

    	args = new String[1];
    	args[0] = "java";

    	/* create the callback objects */
    	callbacks = new JCEngineCallBacks();

    	try{
    		/* start the kernel */
    		kernel = new Engine( args, callbacks, null, null );
    		//	kernel = new Engine( args, new EngineCallBacksDefault(), null, null );
    	}
    	catch ( MapleException e ){
    		System.err.println( e.getMessage()+"\n" );
    		System.err.println( "Error starting OpenMaple session\n" );
    		System.exit(1);
    	}
    }

    public static void main( String args[] ){
    	
    	new Maple(new GUI());  
    	
    	initInputOutput();

    	initKernel();      	
    	
    	Maple.myRun();
    	
    }
    	
    	
    public static void myRun() {    	

    	Algebraic ret; 
    	

    	expr = null;
    	ret = null;


    	done = false;
    	while ( !done ){      		

    		/* get the input */
    		while ( !procitano ) { 
    			try {
    				Thread.sleep(50);
    			} catch (InterruptedException e) {} 
    		}
    		
    		expr = input.getText();
    		
    		
    		if ( done == true){    			
    			break;
    		}
    		
    		/* empty expression */
    		if ( expr.equals( "" ) && Maple.latexAll==false) {
    				continue;
    		}
    	/*	if(Maple.expr.contains("exportplot")) {
    			try {
    				
					Maple.flag = true;
					Maple.kernel.evaluate("with(plottools):");
					Maple.flag= false;
					
				} catch (MapleException e1) {}		
    		}*/
    		
    		if(Maple.latexAll == false && !Maple.notSelected && !Maple.expr.contains("Export")
    			&& !Maple.expr.contains("plot")) {    		
    	
    			try {
    				Maple.staviDodatak = true;
    			
    				Maple.converting = true;
    				kernel.evaluate("latex(  "+ Maple.fun +"  );");
    				Maple.converting = false;				
			
				
    			} catch (MapleException e1) {System.out.print("izuzetak \n");}    		
    		
    	}	
    		   		
    		
    		/* evaluate the expr */
    		try{
    			
    			ret = kernel.evaluate( expr ); 
    			
    			if ( ret != null ){    				
    				done = ret.isStop();
    				ret.dispose();
    			}
    		}catch ( MapleException e ){
    			output.setText(output.getText() + "Error evaluating Maple expression\n" + "\n" );
	    }
    		
    		if(Maple.latexAll == false) {
    			if(expr.contains("latex")) {
    				while ( callbacks.numOfLines() > 0 ){
    					String temp = callbacks.getLine();
    					output2.setText(output2.getText() + temp + "\n" );
    					Maple.callbacks.LatexAll.addLast(temp);
    				}
    			
    			} else {
    				while ( callbacks.numOfLines() > 0 ){
    					
    					String temp = callbacks.getLine();    				
    					output.setText(output.getText() + temp + "\n" );
    					
    					try {
    						if(Maple.expr.contains("taylor")) {
    							
    							Maple.converting = true;
        						
        						Maple.staviDodatak = false; 
        				
        						String[] splited = temp.split(",");
        						
        						splited[0] = splited[0].replace("series(", "");
        					
        						ret = kernel.evaluate("latex("+ splited[0] +");");   
        						     					
        
        						Maple.converting = false;
    						}
    						else {
    							Maple.converting = true;
    							
    							Maple.staviDodatak = false;  
    							
    							String[] splited = temp.split(",");
    						
    							for(int i=0; i<splited.length; i++)
    								ret = kernel.evaluate("latex("+ splited[i] +");");   
    						     					
    
    							Maple.converting = false;
    						}
    					} catch (MapleException e1) {}
    				}
    			}
    		}else {
    			while ( callbacks.LatexAll.size() > 0 ){
					String temp = (String)callbacks.LatexAll.removeFirst();
					output2.setText(output2.getText() + temp + "\n" );
				}
    			
    		}
    		
    		Maple.latexAll = false;
    		procitano = false;    		
    		
    	}

    	try{
    		kernel.stop();
    	}catch ( MapleException me ){}
    }


}
    
    
    
    



