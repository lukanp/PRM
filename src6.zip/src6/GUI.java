import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.maplesoft.externalcall.MapleException; 

public class GUI extends JFrame implements KeyListener {
	
	JTextField polje;
	JButton confirm, clear, clearR, clearL;
	JTextArea area_result, area_latex;
	JRadioButtonMenuItem Solve, Factor, Plot, Taylor, Integrate, Differentiate, Latex, LatexAll;
	ButtonGroup group = new ButtonGroup();
	JLabel label1, label2, label3;
	JScrollPane jp1, jp2;
	

	public GUI(){
		super("Maple");
		
		this.setBounds(160,40, 1050,700);
		this.popuniProzor();
		
		this.setVisible(true);
		
	}

	private void popuniProzor() {		
				
		JPanel left ,leftsouth, right, dugmici, rightsouth, rightnorth, poljetekst, pomocno;
		
		
		this.setLayout(new GridLayout(1,2));	
		
		
		left = new JPanel();
		left.setLayout(new BorderLayout());
		left.setBackground(Color.BLACK);
		
		
		leftsouth = new JPanel();
		leftsouth.setLayout(new GridLayout(1,2));
		
		clearR = new JButton("Clear results");
		clearL = new JButton("Clear latex");
		
		leftsouth.add(clearR);
		leftsouth.add(clearL);
		
		
		right = new JPanel();
		right.setLayout(new GridLayout(2,1));
		
		rightsouth = new JPanel();
		rightsouth.setLayout(new BorderLayout());
		rightsouth.setBackground(Color.BLACK);
		
		rightnorth = new JPanel();
		rightnorth.setLayout(new BorderLayout());
		rightnorth.setBackground(Color.BLACK);
		
		poljetekst = new JPanel();
		poljetekst.setLayout(new GridLayout(2,1));
		
		pomocno = new JPanel();
		pomocno.setLayout(new GridLayout(1,2));
		
		dugmici = new JPanel();
		dugmici.setBackground(Color.WHITE);
		dugmici.setLayout( new GridLayout(4,2));
		
		area_result = new JTextArea(390,300);
		area_result.setBounds(50, 100, 380, 240);
		area_result.setEditable(false);
		area_latex = new JTextArea();		
		area_result.setLineWrap(true);
	//	area_result.setFont(new Font("Marija", 0, 20));
		area_latex.setFont(new Font("Nikola", 0, 18));
		
		

		left.setBounds(10, 10, 330, 580);
		
		this.polje = new JTextField();
		polje.setFont(new Font("Luka", 0 , 20));
		polje.setBounds(0, 0, 20, 20);
		
		
		
		
		pomocno.add(this.clear = new JButton("Clear"));
		pomocno.add(this.confirm = new JButton("Confirm"));
		poljetekst.add(polje);
		
		polje.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				polje.setForeground(Color.BLACK);
				polje.setText("");
			}
			
		});
		
		
		poljetekst.add(pomocno);

		
		group.add(Solve=new JRadioButtonMenuItem("Solve", false));
		Solve.setFont(new Font("Jokic", 0,25));
		Solve.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x)");
				
				
			}
			
		});
		dugmici.add(Solve, BorderLayout.CENTER);
		group.add(Factor=new JRadioButtonMenuItem("Factor", false));
		Factor.setFont(new Font("NazivFonta", 0,25));
		Factor.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x)");
				
				
			}
			
		});
		dugmici.add(Factor);
		group.add(Plot=new JRadioButtonMenuItem("Plot", false));
		Plot.setFont(new Font("PrazanString", 0,25));
		Plot.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x=a..b");
				
				
			}
			
		});
		dugmici.add(Plot);
		group.add(Taylor=new JRadioButtonMenuItem("Taylor", false));
		Taylor.setFont(new Font("prazan", 0, 25));
		Taylor.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x, num");
				
				
			}
			
		});
		dugmici.add(Taylor);
		group.add(Integrate=new JRadioButtonMenuItem("Integrate", false));
		Integrate.setFont(new Font("",0,25));
		Integrate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x=a..b");
				
				
			}
			
		});
		dugmici.add(Integrate);
		group.add(Differentiate=new JRadioButtonMenuItem("Differentiate", false));
		Differentiate.setFont(new Font("", 0, 25));
		Differentiate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x), x");
				
				
			}
			
		});
		dugmici.add(Differentiate);
		group.add(Latex=new JRadioButtonMenuItem("Latex", false));
		Latex.setFont(new Font("",0,25));
		Latex.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				polje.setForeground(Color.LIGHT_GRAY);
				polje.setText("f(x)");
				
				
			}
			
		});
		dugmici.add(Latex);
		group.add(LatexAll=new JRadioButtonMenuItem("LatexAll", false));
		LatexAll.setFont(new Font("",0,25));
		dugmici.add(LatexAll);
	
		Solve.setBackground(Color.BLACK);
		Solve.setForeground(Color.WHITE);
		Factor.setBackground(Color.BLACK);
		Factor.setForeground(Color.WHITE);
		Plot.setBackground(Color.BLACK);
		Plot.setForeground(Color.WHITE);
		Taylor.setBackground(Color.BLACK);
		Taylor.setForeground(Color.WHITE);
		Integrate.setBackground(Color.BLACK);
		Integrate.setForeground(Color.WHITE);
		Differentiate.setBackground(Color.BLACK);
		Differentiate.setForeground(Color.WHITE);
		Latex.setBackground(Color.BLACK);
		Latex.setForeground(Color.WHITE);
		LatexAll.setBackground(Color.BLACK);
		LatexAll.setForeground(Color.WHITE);
		
		
		left.setBorder(new EmptyBorder(10,10,10,5));
		rightnorth.setBorder(new EmptyBorder(10,5,10,10));
		rightsouth.setBorder(new EmptyBorder(10,5,10,10));

		
		rightnorth.add(label2=new JLabel ("Most common functions in Maple", JLabel.CENTER), BorderLayout.NORTH);
		rightnorth.add(dugmici, BorderLayout.CENTER);
		rightnorth.add(poljetekst, BorderLayout.SOUTH);
		
		rightsouth.add(label3 = new JLabel("Latex area", JLabel.CENTER), BorderLayout.NORTH);
		rightsouth.add(area_latex, BorderLayout.CENTER);
		
		right.add(rightnorth, BorderLayout.NORTH);
		right.add(rightsouth, BorderLayout.SOUTH);
		
		left.add(label1 =new JLabel("Maple result", JLabel.CENTER), BorderLayout.NORTH);
		
		left.add(area_result);		
		
		left.add(leftsouth, BorderLayout.SOUTH);
		
		label1.setForeground(Color.WHITE);
		label1.setFont(new Font("",0,25));
		label2.setForeground(Color.WHITE);
		label2.setFont(new Font("",0,25));
		label3.setForeground(Color.WHITE);
		label3.setFont(new Font("",0,25));
		
		jp1=new JScrollPane(area_result, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp2=new JScrollPane(area_latex, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		left.add(jp1);
		rightsouth.add(jp2);
		
		
		this.add(left, BorderLayout.WEST);
		this.add(right, BorderLayout.EAST);
		
		
		this.polje.addKeyListener(this);
		
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				polje.setText("");
				group.clearSelection();			
				
			}
		});		
		
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Maple.procitano = true;
				Maple.done = true;
				dispose();
			}
		});
		
		
		confirm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {				
				
				String fja=polje.getText();						
				polje.setText("");
				String txt = "";
				
				Maple.notSelected = false;
				if(Solve.isSelected() || fja.contains("solve")) {
					if(!fja.contains("solve")) {
						Maple.fun = fja;
						txt="solve("+ fja + ");";
					}else {
						String s = "[(][ ]*(?<naziv>(.*)?)[ ]*[)];";
						Pattern p = Pattern.compile(s);
						Matcher matcher = p.matcher(fja);
						
						if(matcher.find())
							Maple.fun = matcher.group("naziv");
						
						txt=fja;
					}
					Maple.dodatak = "$$";
					polje.setText(txt);
					
				}
				else if(Factor.isSelected() || fja.contains("factor")) {
					if(!fja.contains("factor")) {
						Maple.fun = fja;
						txt="factor("+fja+");";
					}else {
						String s = "[(][ ]*(?<naziv>(.*)?)[ ]*[)];";
						Pattern p = Pattern.compile(s);
						Matcher matcher = p.matcher(fja);
						
						if(matcher.find())
							Maple.fun = matcher.group("naziv");
						System.out.println(Maple.fun);
						txt=fja;
					}
					Maple.dodatak = "$$factor(";
					polje.setText(txt);
				}
				else if(Plot.isSelected() || fja.contains("plot")) {					
					
					/*txt="exportplot("+ "\"C:/Users/asus/Desktop/abc.jpeg\""+ ","+
						"plot("+fja+ "),jpeg);";*/
					txt = "Export( \"a.jpg\" , " + "plot(" + fja + ") , "+ "base = homedir);";
				//	txt = "Export[interactive]( " + "plot(" + fja + ")" + ");";
					
					Maple.dodatak = "plot(";
					polje.setText(txt);
				}
				else if(Taylor.isSelected() || fja.contains("taylor")) {
					if(!fja.contains("taylor")) {
						String[] temp=fja.split(",");					
						
						Maple.fun=temp[0];
						Maple.promenjiva=temp[1];
						Maple.stepen=temp[2];
						txt="taylor("+fja+");";
					}else {
						String s = "[(][ ]*(?<naziv>(.*)?)[ ]*[)];";
						Pattern p = Pattern.compile(s);
						Matcher matcher = p.matcher(fja);
						
						String str = "";
						if(matcher.find())
							str = matcher.group("naziv");
						
						String[] temp=str.split(",");					
						
						Maple.fun=temp[0];
						Maple.promenjiva=temp[1];
						Maple.stepen=temp[2];
						
						txt=fja;
					}
					
					Maple.dodatak = "$$taylor(";
					polje.setText(txt);
				}
				else if(Integrate.isSelected() || fja.contains("integrate")) {
					if(!fja.contains("integrate")) {
						fja.replace(" ", "");
						String[] temp=fja.split(",");
						Maple.fun = temp[0];
						
						String[] temp1=temp[1].split("=");
						
						Maple.promenjiva = temp1[0];						
						Maple.fun = temp[0];
						
						String s2 = "(?<naziv1>(.*)?)\\.\\.(?<naziv2>(.*)?)";
						Pattern p2 = Pattern.compile(s2);
						Matcher matcher2 = p2.matcher(temp1[1]);
						String a="" , b="";
						matcher2.find();
						a = matcher2.group("naziv1");					
						b = matcher2.group("naziv2");
						
						Maple.dodatak = "$$\\int_{" + a + "}^{" + b +"}";
						txt="integrate("+fja+");";
						
					}else {
						String s = "[(][ ]*(?<naziv>(.*)?)[ ]*[)];";
						Pattern p = Pattern.compile(s);
						Matcher matcher = p.matcher(fja);
						String str="";
						
						if(matcher.find())
							str = matcher.group("naziv");
						
						str.replace(" ", "");
						String[] temp=str.split(",");
						Maple.fun = temp[0];
						
						String[] temp1=temp[1].split("=");
						
						Maple.promenjiva = temp1[0];
						
						Maple.fun = temp[0];
						//////////
						String s2 = "(?<naziv1>(.*)?)\\.\\.(?<naziv2>(.*)?)";
						Pattern p2 = Pattern.compile(s2);
						Matcher matcher2 = p2.matcher(temp1[1]);
						String a="" , b="";
						matcher2.find();
						a = matcher2.group("naziv1");					
						b = matcher2.group("naziv2");
						
						///////
						Maple.dodatak = "$$\\int_{" + a + "}^{" + b + "}";
						txt=fja;						
					}			
				
					
					polje.setText(txt);
				}
				else if(Differentiate.isSelected() || fja.contains("diff")) {
					if(!fja.contains("diff")) {
						
						String[] temp = fja.split(",");
						Maple.fun = temp[0];
						Maple.promenjiva = temp[1];
						
						
						txt="diff("+fja+");";
					}else {
						String s = "[(][ ]*(?<naziv>(.*)?)[ ]*[)];";
						Pattern p = Pattern.compile(s);
						Matcher matcher = p.matcher(fja);
						String str = "";
						if(matcher.find())
							str = matcher.group("naziv");
						
						String[] temp = str.split(",");
						Maple.fun = temp[0];
						Maple.promenjiva = temp[1];
						
						txt=fja;
					}
					
					Maple.dodatak = "$$\\frac{d (";
					polje.setText(txt);
				}
				else if(Latex.isSelected() || fja.contains("latex")) {		
					if(!fja.contains("latex")) {
						Maple.fun = fja;
						txt="latex("+fja+");";
					}else {
						String s = "[(][ ]*(?<naziv>(.*)?)[ ]*[)];";
						Pattern p = Pattern.compile(s);
						Matcher matcher = p.matcher(fja);
				
						if(matcher.find())
							Maple.fun = matcher.group("naziv");
						
						txt=fja;
					}
				}else if(LatexAll.isSelected()) {					
					Maple.latexAll = true;
					txt="";
					polje.setText(txt);
				}
	
				else {
					Maple.notSelected = true;
					if (fja == "") { 
					txt="";
					polje.setText(txt);
					}
					else {
						txt=fja;
						polje.setText(fja);
					}
				}
								
				area_result.setText(area_result.getText() + " " + txt + "\n");				
				
				group.clearSelection();				
				
				Maple.procitano = true;

			}
			
		});
		
		
		clearR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				area_result.setText("");
			}
		});
		
		clearL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				area_latex.setText("");
			
			}
		});
		
		
	}



	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			
			confirm.doClick();	
			
			group.clearSelection();			
			
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
		
}
	
	
